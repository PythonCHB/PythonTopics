# the very simplest setup.py you can have for managing your personal code collection.

from setuptools import setup

setup(name='my_code',
      packages=['my_code'],
      )
