#!/usr/bin/env python

"""
Just an example, but this could be a collection of utility functions, etc.

and up here would be documentation of what's in here

in this case, jsut one function to make sure it works
"""


def test_fun():
    print("yup -- this worked!!")
